# Test Storage Plugin

这是一个测试存储器插件。

## 功能特性

- 支持数据存储
- 提供API接口
- 兼容MicroDock系统

## 安装方法

1. 下载插件包
2. 上传到MicroDock插件管理器
3. 重启应用程序

## 版本信息

- 版本: 1.2.3
- 作者: Plugin Developer Team
- 类型: Storage Plugin

## 依赖项

- MicroDock.Plugin
- System.Reactive